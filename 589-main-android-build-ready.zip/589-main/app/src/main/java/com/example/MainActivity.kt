package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppScreen
import com.example.data.model.LobbyDialogType
import com.example.ui.dialogs.ActivityCenterDialog
import com.example.ui.dialogs.AdminPaymentConfigDialog
import com.example.ui.dialogs.BankVaultDialog
import com.example.ui.dialogs.BindBankAccountDialog
import com.example.ui.dialogs.BindBankCardDialog
import com.example.ui.dialogs.CustomerServiceDialog
import com.example.ui.dialogs.DepositDialog
import com.example.ui.dialogs.DepositTransferDialog
import com.example.ui.dialogs.ExitConfirmDialog
import com.example.ui.dialogs.GameDemoDialog
import com.example.ui.dialogs.InstantAlertNotice
import com.example.ui.dialogs.ProfileDialog
import com.example.ui.dialogs.SettingsDialog
import com.example.ui.dialogs.TransactionHistoryDialog
import com.example.ui.dialogs.VipDialog
import com.example.ui.dialogs.WithdrawDialog
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MainLobbyScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.LobbyViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: LobbyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    LobbyAppRoot(
                        viewModel = viewModel,
                        onExitApp = { finish() },
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun LobbyAppRoot(
    viewModel: LobbyViewModel,
    onExitApp: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val activeDialog by viewModel.activeDialog.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val adminPayment by viewModel.adminPayment.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val withdrawHistory by viewModel.withdrawHistory.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    val selectedDepositMethod by viewModel.selectedDepositMethod.collectAsState()
    val depositAmount by viewModel.depositAmount.collectAsState()
    val depositReceiptCode by viewModel.depositReceiptCode.collectAsState()
    val depositPayerName by viewModel.depositPayerName.collectAsState()

    val withdrawAmount by viewModel.withdrawAmount.collectAsState()
    val bindBankName by viewModel.bindBankName.collectAsState()
    val bindAccountNumber by viewModel.bindAccountNumber.collectAsState()
    val bindAccountHolder by viewModel.bindAccountHolder.collectAsState()
    val selectedGame by viewModel.selectedGame.collectAsState()

    val csInputText by viewModel.csInputText.collectAsState()
    val csActiveTab by viewModel.csActiveTab.collectAsState()

    // Handle Hardware Back button
    BackHandler {
        if (activeDialog != LobbyDialogType.NONE) {
            viewModel.closeDialog()
        } else if (currentScreen == AppScreen.LOBBY) {
            viewModel.openDialog(LobbyDialogType.EXIT_CONFIRM)
        } else if (currentScreen == AppScreen.LOGIN) {
            onExitApp()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        // Screen Switching
        when (currentScreen) {
            AppScreen.SPLASH -> {
                SplashScreen(
                    onTimeout = { viewModel.navigateTo(AppScreen.LOGIN) }
                )
            }
            AppScreen.LOGIN -> {
                LoginScreen(
                    onQuickLogin = { viewModel.loginQuickGuest() },
                    onPasswordLogin = { pwd -> viewModel.loginWithPassword(pwd) },
                    onViberClick = { viewModel.openDialog(LobbyDialogType.CUSTOMER_SERVICE) },
                    onExitClick = { viewModel.openDialog(LobbyDialogType.EXIT_CONFIRM) }
                )
            }
            AppScreen.LOBBY -> {
                MainLobbyScreen(
                    userProfile = userProfile,
                    gameCards = viewModel.gameCards,
                    onProfileClick = { viewModel.openDialog(LobbyDialogType.PROFILE) },
                    onVipClick = { viewModel.openDialog(LobbyDialogType.VIP_BENEFITS) },
                    onDepositClick = { viewModel.openDialog(LobbyDialogType.DEPOSIT) },
                    onWithdrawClick = { viewModel.openDialog(LobbyDialogType.WITHDRAW) },
                    onBindAccountClick = { viewModel.openDialog(LobbyDialogType.BIND_BANK) },
                    onVaultClick = { viewModel.openDialog(LobbyDialogType.BANK_VAULT) },
                    onCsClick = { viewModel.openDialog(LobbyDialogType.CUSTOMER_SERVICE) },
                    onActivityClick = { viewModel.openDialog(LobbyDialogType.ACTIVITY_CENTER) },
                    onSettingsClick = { viewModel.openDialog(LobbyDialogType.SETTINGS) },
                    onOfficialWebsiteClick = {
                        viewModel.copyToClipboard("https://589slot.co", "တရားဝင်ဝက်ဆိုက်")
                    },
                    onGameClick = { game -> viewModel.onGameCardClicked(game) }
                )
            }
        }

        // Active Dialogs Overlay
        when (activeDialog) {
            LobbyDialogType.PROFILE -> {
                ProfileDialog(
                    userProfile = userProfile,
                    onClose = { viewModel.closeDialog() },
                    onBindAccount = { viewModel.openDialog(LobbyDialogType.BIND_BANK) },
                    onLogout = {
                        viewModel.closeDialog()
                        viewModel.navigateTo(AppScreen.LOGIN)
                    },
                    onViewVip = { viewModel.openDialog(LobbyDialogType.VIP_BENEFITS) },
                    onUpdateNickname = { newName -> viewModel.updateNickname(newName) },
                    onCopy = { text, label -> viewModel.copyToClipboard(text, label) }
                )
            }
            LobbyDialogType.DEPOSIT -> {
                DepositDialog(
                    selectedMethod = selectedDepositMethod,
                    depositAmount = depositAmount,
                    onSelectMethod = { m -> viewModel.setDepositMethod(m) },
                    onSelectAmount = { a -> viewModel.setDepositAmount(a) },
                    onConfirm = { viewModel.proceedToDepositTransfer() },
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.DEPOSIT_TRANSFER -> {
                DepositTransferDialog(
                    adminInfo = adminPayment,
                    selectedMethod = selectedDepositMethod,
                    depositAmount = depositAmount,
                    receiptCode = depositReceiptCode,
                    payerName = depositPayerName,
                    onReceiptCodeChange = { code -> viewModel.setDepositReceiptCode(code) },
                    onPayerNameChange = { name -> viewModel.setDepositPayerName(name) },
                    onConfirm = { viewModel.confirmDepositTransfer() },
                    onCancel = { viewModel.closeDialog() },
                    onCopy = { text, label -> viewModel.copyToClipboard(text, label) }
                )
            }
            LobbyDialogType.INSTANT_ALERT -> {
                InstantAlertNotice(
                    onConfirm = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.WITHDRAW -> {
                WithdrawDialog(
                    userProfile = userProfile,
                    withdrawAmount = withdrawAmount,
                    onWithdrawAmountChange = { a -> viewModel.setWithdrawAmount(a) },
                    onMaxAmount = { viewModel.setMaxWithdrawAmount() },
                    onOpenRecords = { viewModel.openDialog(LobbyDialogType.TRANSACTION_HISTORY) },
                    onBindBankCard = { viewModel.openDialog(LobbyDialogType.BIND_BANK_CARD) },
                    onConfirmWithdraw = { viewModel.confirmWithdraw() },
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.BIND_BANK -> {
                BindBankAccountDialog(
                    selectedBank = bindBankName,
                    accountNumber = bindAccountNumber,
                    onSelectBank = { b -> viewModel.setBindBankName(b) },
                    onAccountNumberChange = { n -> viewModel.setBindAccountNumber(n) },
                    onSubmit = { viewModel.confirmBankBinding() },
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.BIND_BANK_CARD -> {
                BindBankCardDialog(
                    holderName = bindAccountHolder,
                    cardNumber = bindAccountNumber,
                    onHolderNameChange = { h -> viewModel.setBindAccountHolder(h) },
                    onCardNumberChange = { n -> viewModel.setBindAccountNumber(n) },
                    onSubmit = { viewModel.confirmBankBinding() },
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.TRANSACTION_HISTORY -> {
                TransactionHistoryDialog(
                    historyList = withdrawHistory,
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.SETTINGS -> {
                SettingsDialog(
                    settings = settings,
                    onToggleMusic = { viewModel.toggleMusic() },
                    onToggleSound = { viewModel.toggleSound() },
                    onToggleFx = { viewModel.toggleFx() },
                    onToggleAnnouncements = { viewModel.toggleAnnouncements() },
                    onOpenAdminConfig = { viewModel.openDialog(LobbyDialogType.ADMIN_PAYMENT_CONFIG) },
                    onResetDemo = { viewModel.resetDemoData() },
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.CUSTOMER_SERVICE -> {
                CustomerServiceDialog(
                    chatMessages = chatMessages,
                    activeTab = csActiveTab,
                    inputText = csInputText,
                    onTabSelect = { tab -> viewModel.setCsActiveTab(tab) },
                    onInputChange = { t -> viewModel.setCsInputText(t) },
                    onSendMessage = { viewModel.sendCsMessage() },
                    onPhotoClick = { viewModel.showToast("ဓာတ်ပုံ ရွေးချယ်မှု (Demo)") },
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.VIP_BENEFITS -> {
                VipDialog(
                    userProfile = userProfile,
                    onClaimDailyBonus = {
                        viewModel.showToast("နေ့စဉ် VIP ဆုလာဘ် 1,000 Coins ရရှိပါသည်!")
                    },
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.BANK_VAULT -> {
                BankVaultDialog(
                    userProfile = userProfile,
                    onDepositToVault = {
                        viewModel.showToast("သေတ္တာထဲသို့ အောင်မြင်စွာ သိမ်းဆည်းခဲ့သည် (Demo)")
                    },
                    onWithdrawFromVault = {
                        viewModel.showToast("သေတ္တာထဲမှ အောင်မြင်စွာ ထုတ်ယူခဲ့သည် (Demo)")
                    },
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.ACTIVITY_CENTER -> {
                ActivityCenterDialog(
                    onClaimSpin = {
                        viewModel.showToast("ကံစမ်းမဲ ပါဝင်ခွင့်ရရှိပါသည်! +500 Coins")
                    },
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.GAME_DEMO -> {
                GameDemoDialog(
                    game = selectedGame,
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.EXIT_CONFIRM -> {
                ExitConfirmDialog(
                    onConfirmExit = {
                        viewModel.closeDialog()
                        onExitApp()
                    },
                    onCancel = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.ADMIN_PAYMENT_CONFIG -> {
                AdminPaymentConfigDialog(
                    currentInfo = adminPayment,
                    onSave = { kbzN, kbzP, waveN, waveP ->
                        viewModel.updateAdminPayment(kbzN, kbzP, waveN, waveP)
                    },
                    onClose = { viewModel.closeDialog() }
                )
            }
            LobbyDialogType.NONE -> {}
        }

        // Custom Casino Floating Toast Notification
        AnimatedVisibility(
            visible = toastMessage != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 56.dp)
        ) {
            if (toastMessage != null) {
                Box(
                    modifier = Modifier
                        .shadow(8.dp, RoundedCornerShape(percent = 50))
                        .clip(RoundedCornerShape(percent = 50))
                        .background(Color(0xEE2A0104))
                        .border(1.5.dp, CasinoGoldPrimary, RoundedCornerShape(percent = 50))
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = toastMessage!!,
                        color = CasinoGoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
