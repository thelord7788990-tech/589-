package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CasinoColorScheme = darkColorScheme(
    primary = CasinoGoldPrimary,
    onPrimary = Color.Black,
    primaryContainer = CasinoRedDark,
    onPrimaryContainer = CasinoGoldLight,
    secondary = CasinoGreenPrimary,
    onSecondary = Color.White,
    tertiary = CasinoPurplePrimary,
    background = CasinoLobbyBackground,
    onBackground = Color.White,
    surface = CasinoPanelBackground,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF4A0A10),
    onSurfaceVariant = CasinoGoldLight
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CasinoColorScheme,
        typography = Typography,
        content = content
    )
}
