package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdminPaymentInfo
import com.example.ui.components.CopyPillButton
import com.example.ui.components.GreenPillButton
import com.example.ui.components.RedPillButton
import com.example.ui.components.TempleRoofDialog
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoGreenDark
import com.example.ui.theme.CasinoGreenLight
import com.example.ui.theme.CasinoGreenPrimary
import com.example.ui.theme.CasinoRedBright
import com.example.ui.theme.CasinoRedDark
import com.example.ui.theme.CasinoRedPrimary

/**
 * Screenshot 7 & 10: Deposit Main Dialog ("ဖြည့်ပါ")
 */
@Composable
fun DepositDialog(
    selectedMethod: String,
    depositAmount: Long,
    onSelectMethod: (String) -> Unit,
    onSelectAmount: (Long) -> Unit,
    onConfirm: () -> Unit,
    onClose: () -> Unit
) {
    val quickAmounts = listOf(
        2000L to "2K",
        5000L to "5K",
        10000L to "10K",
        30000L to "30K",
        50000L to "50K",
        100000L to "100K",
        200000L to "200K",
        500000L to "500K"
    )

    TempleRoofDialog(
        title = "ဖြည့်ပါ",
        onClose = onClose,
        bottomActionText = "သေချာပါတယ်",
        onBottomAction = onConfirm,
        modifier = Modifier.testTag("deposit_dialog_root")
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Left Side Method Selector Tabs (KBZ Pay / WAVEPAY)
            Column(
                modifier = Modifier
                    .width(130.dp)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // KBZ Pay Tab
                val isKbz = selectedMethod == "KBZ Pay"
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .shadow(3.dp, RoundedCornerShape(6.dp))
                        .background(
                            brush = if (isKbz) {
                                Brush.verticalGradient(
                                    listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                                )
                            } else {
                                Brush.verticalGradient(
                                    listOf(Color(0xFF5A2226), Color(0xFF381215))
                                )
                            },
                            shape = RoundedCornerShape(6.dp)
                        )
                        .border(
                            1.5.dp,
                            if (isKbz) Color.White else CasinoGoldDark,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectMethod("KBZ Pay") }
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Blue KBZ Logo Badge
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(Color(0xFF005696), RoundedCornerShape(3.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "KBZ",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "KBZ",
                            color = if (isKbz) Color(0xFF3B1E00) else Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                // WavePay Tab
                val isWave = selectedMethod == "WAVEPAY"
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .shadow(3.dp, RoundedCornerShape(6.dp))
                        .background(
                            brush = if (isWave) {
                                Brush.verticalGradient(
                                    listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                                )
                            } else {
                                Brush.verticalGradient(
                                    listOf(Color(0xFF5A2226), Color(0xFF381215))
                                )
                            },
                            shape = RoundedCornerShape(6.dp)
                        )
                        .border(
                            1.5.dp,
                            if (isWave) Color.White else CasinoGoldDark,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectMethod("WAVEPAY") }
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Yellow/Blue Wave Logo Badge
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(Color(0xFFFFEB3B), RoundedCornerShape(3.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🌊",
                                fontSize = 11.sp
                            )
                        }
                        Text(
                            text = "WAVEPAY",
                            color = if (isWave) Color(0xFF3B1E00) else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            // Right Pane: Header + Amount Display + Quick Amount Buttons
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Header: Method Logo + Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (selectedMethod == "KBZ Pay") Color(0xFF005696) else Color(0xFFFFD600),
                                RoundedCornerShape(4.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (selectedMethod == "KBZ Pay") "KBZ\nPay" else "WAVE\nPay",
                            color = if (selectedMethod == "KBZ Pay") Color.White else Color(0xFF004D40),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            lineHeight = 10.sp
                        )
                    }

                    Text(
                        text = "$selectedMethod ဖြည့်ပါ",
                        color = CasinoGoldLight,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Displayed Amount Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(34.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = depositAmount.toString(),
                        color = CasinoGoldLight,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                // 2x4 / 3x3 Quick Amount Buttons in Green
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(quickAmounts) { (amt, label) ->
                        val isSelected = depositAmount == amt
                        Box(
                            modifier = Modifier
                                .height(32.dp)
                                .shadow(2.dp, RoundedCornerShape(4.dp))
                                .background(
                                    brush = Brush.verticalGradient(
                                        if (isSelected) {
                                            listOf(Color(0xFF69F0AE), CasinoGreenPrimary, CasinoGreenDark)
                                        } else {
                                            listOf(CasinoGreenLight, CasinoGreenPrimary, CasinoGreenDark)
                                        }
                                    ),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .border(
                                    if (isSelected) 2.dp else 1.dp,
                                    if (isSelected) Color.White else CasinoGoldLight,
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { onSelectAmount(amt) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Screenshot 8: Payment Transfer Demo Screen ("ငွေပေးချေမှု လွှဲပြောင်းခြင်း")
 */
@Composable
fun DepositTransferDialog(
    adminInfo: AdminPaymentInfo,
    selectedMethod: String,
    depositAmount: Long,
    receiptCode: String,
    payerName: String,
    onReceiptCodeChange: (String) -> Unit,
    onPayerNameChange: (String) -> Unit,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    onCopy: (String, String) -> Unit
) {
    val accountName = if (selectedMethod == "KBZ Pay") adminInfo.kbzName else adminInfo.waveName
    val accountNumber = if (selectedMethod == "KBZ Pay") adminInfo.kbzPhone else adminInfo.wavePhone

    TempleRoofDialog(
        title = "ငွေပေးချေမှု လွှဲပြောင်းခြင်း",
        onClose = onCancel,
        modifier = Modifier.testTag("deposit_transfer_dialog_root")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            // Row 1: Bank User Name
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ဘဏ်အသုံးပြုသူအမည်",
                    color = CasinoGoldLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(135.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(text = accountName, color = Color.White, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.width(6.dp))
                CopyPillButton(onClick = { onCopy(accountName, "အသုံးပြုသူအမည်") })
            }

            // Row 2: Bank Account / Phone
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ဘဏ်ကတ်နံပါတ်",
                    color = CasinoGoldLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(135.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(text = accountNumber, color = Color.White, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.width(6.dp))
                CopyPillButton(onClick = { onCopy(accountNumber, "ဘဏ်ကတ်နံပါတ်") })
            }

            // Row 3: Last 5 Digits Input
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ငွေလွှဲပြေစာ၏နောက်ဆုံး\n၅ဂဏန်းဖြည့်ပါ",
                    color = CasinoGoldLight,
                    fontSize = 10.sp,
                    lineHeight = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(135.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    OutlinedTextField(
                        value = receiptCode,
                        onValueChange = onReceiptCodeChange,
                        placeholder = { Text("ဥပမာ: 12345", color = Color.Gray, fontSize = 11.sp) },
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Row 4: Payer Name Input
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ကျေးဇူးပြု၍ ငွေပေးချေ\nသူ၏အမည်ကိုရိုက်ထည့်ပါ",
                    color = CasinoGoldLight,
                    fontSize = 10.sp,
                    lineHeight = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(135.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    OutlinedTextField(
                        value = payerName,
                        onValueChange = onPayerNameChange,
                        placeholder = { Text("ငွေလွှဲသူအမည်", color = Color.Gray, fontSize = 11.sp) },
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Row 5: Deposit Amount
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ငွေသွင်းသည့်ပမာဏ",
                    color = CasinoGoldLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.width(135.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(text = depositAmount.toString(), color = CasinoGoldLight, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Explanatory Notice
            Text(
                text = "ကျေးဇူးပြု၍ငွေလွှဲပြေစာမှာပါသောလုပ်ငန်းစဉ်နံပါတ်နောက်ဆုံး ၅ လုံးကိုပေးပို့ပြီးပါကသင်၏ဒင်္ဂါးများကိုအကောင့်ထဲသို့အလိုအလျောက် ထည့်ပေးပါလိမ့်မည်။ ကျေးဇူးပြုပြီးငွေတစ်ခါသွင်းမည်ဆိုတိုင်း ဂိမ်းထဲသို့ ဝင်ကြည့်ပေးပါရန် သတိပေးကြေညာအပ်ပါသည် (စာရင်းများကို ထပ်ခါထပ်ခါမတင်ကြရန်သတိပေးအပ်ပါသည်)။",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 9.sp,
                lineHeight = 11.sp,
                modifier = Modifier.padding(top = 2.dp)
            )

            // Buttons: Cancel (Red) & Confirm (Green)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                RedPillButton(text = "ပယ်ဖျက်ပါ", onClick = onCancel, height = 30.dp, fontSize = 12)
                GreenPillButton(text = "သေချာပါတယ်", onClick = onConfirm, height = 30.dp, fontSize = 12)
            }
        }
    }
}

/**
 * Screenshot 11: Instant Notification ("ချက်ချင်း သတိပေးခြင်း")
 */
@Composable
fun InstantAlertNotice(
    onConfirm: () -> Unit
) {
    TempleRoofDialog(
        title = "ချက်ချင်း သတိပေးခြင်း",
        onClose = onConfirm,
        bottomActionText = "သေချာပါတယ်",
        onBottomAction = onConfirm,
        modifier = Modifier.testTag("instant_alert_notice_root")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "ပြန်လည်သုံးသပ်နေပါသဖြင့် (၃) မိနစ်အတွင်း ပြန်လည်သုံးသပ်အောင်မြင်ပြီးနောက် စနစ်အလိုအလျောက် ငွေဒင်္ဂါးများရောက်ရှိလာမည်၊ မေးခွန်းတစ်ခုခုရှိပါက ဝန်ဆောင်မှုဌာနသို့ ဆက်သွယ်ပါ",
                color = Color.White,
                fontSize = 14.sp,
                lineHeight = 22.sp,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
