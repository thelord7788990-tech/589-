package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.WithdrawItem
import com.example.ui.components.TempleRoofDialog
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoRedBright
import com.example.ui.theme.CasinoRedDark
import com.example.ui.theme.CasinoRedPrimary

@Composable
fun TransactionHistoryDialog(
    historyList: List<WithdrawItem>,
    onClose: () -> Unit
) {
    var currentPage by remember { mutableIntStateOf(0) }
    var selectedItemForDetail by remember { mutableStateOf<WithdrawItem?>(null) }

    val pageSize = 6
    val totalPages = maxOf(1, (historyList.size + pageSize - 1) / pageSize)
    val pagedList = historyList.drop(currentPage * pageSize).take(pageSize)

    TempleRoofDialog(
        title = "ငွေထုတ်မှတ်တမ်း",
        onClose = onClose,
        modifier = Modifier.testTag("transaction_history_dialog_root")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Table Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp)
                    .background(Color(0xFF520106))
                    .border(1.dp, CasinoGoldDark),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ဘဏ်အမျိုးအစား",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1.1f)
                )
                Text(
                    text = "ငွေလဲလှယ်နံပါတ်",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1.8f)
                )
                Text(
                    text = "ငွေပမာဏ",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1.1f)
                )
                Text(
                    text = "ငွေထုတ်ယူခြင်း",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1.8f)
                )
                Text(
                    text = "အခြေအနေ",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1.1f)
                )
                Text(
                    text = "လည်ပတ်",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1.1f)
                )
            }

            // Table Rows
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                items(pagedList) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp)
                            .background(Color(0xFF2C0104))
                            .border(0.5.dp, Color(0xFF4E0D12)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.bankType,
                            color = Color.White,
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.1f)
                        )
                        Text(
                            text = item.transId,
                            color = Color.White,
                            fontSize = 9.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.8f)
                        )
                        Text(
                            text = item.amount.toString(),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.1f)
                        )
                        Text(
                            text = item.date,
                            color = Color.White,
                            fontSize = 9.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.8f)
                        )
                        Text(
                            text = item.status,
                            color = Color.White,
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1.1f)
                        )

                        // Action: "အသေးစိတ်" (Details)
                        Box(
                            modifier = Modifier
                                .weight(1.1f)
                                .clickable { selectedItemForDetail = item },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "အသေးစိတ်",
                                color = CasinoGoldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline
                            )
                        }
                    }
                }
            }

            // Footer with Pagination and Golden Lion Statues
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Golden lion emoji/ornament + label
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🦁", fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "တစ်ခုချင်းစီလျှင် မှတ်တမ်း ၆ ခုအထိ",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 10.sp
                    )
                }

                // Page Navigation Buttons: "နောက်စာမျက်နှာ" & "ရှေ့စာမျက်နှာ"
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Next / Prev buttons
                    Box(
                        modifier = Modifier
                            .height(24.dp)
                            .background(
                                brush = Brush.verticalGradient(
                                    listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                                ),
                                shape = RoundedCornerShape(3.dp)
                            )
                            .border(1.dp, Color.White, RoundedCornerShape(3.dp))
                            .clickable {
                                if (currentPage > 0) currentPage--
                            }
                            .padding(horizontal = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "ရှေ့စာမျက်နှာ",
                            color = Color(0xFF381400),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .height(24.dp)
                            .background(
                                brush = Brush.verticalGradient(
                                    listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                                ),
                                shape = RoundedCornerShape(3.dp)
                            )
                            .border(1.dp, Color.White, RoundedCornerShape(3.dp))
                            .clickable {
                                if (currentPage < totalPages - 1) currentPage++
                            }
                            .padding(horizontal = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "နောက်စာမျက်နှာ",
                            color = Color(0xFF381400),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text("🦁", fontSize = 16.sp)
                }
            }
        }
    }

    // Details Dialog
    if (selectedItemForDetail != null) {
        val item = selectedItemForDetail!!
        AlertDialog(
            onDismissRequest = { selectedItemForDetail = null },
            title = {
                Text(
                    text = "ငွေထုတ်ယူမှု အသေးစိတ်",
                    color = CasinoGoldLight,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("လွှဲပြောင်းမှု ID: ${item.transId}", color = Color.White, fontSize = 12.sp)
                    Text("ဘဏ်အမျိုးအစား: ${item.bankType}", color = Color.White, fontSize = 12.sp)
                    Text("ငွေပမာဏ: ${item.amount} ကျပ်", color = CasinoGoldPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("အချိန်: ${item.date}", color = Color.White, fontSize = 12.sp)
                    Text("အခြေအနေ: ${item.status}", color = Color(0xFF00E676), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedItemForDetail = null }) {
                    Text("ပိတ်ပါ", color = CasinoGoldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF3B0206)
        )
    }
}
