package com.example.data.model

data class UserProfile(
    val userId: String = "79018626",
    val nickname: String = "79018626",
    val accountName: String = "Khant Hein soe",
    val phone: String = "09666769539",
    val coinBalance: Long = 13,
    val syceeBalance: Long = 5,
    val vipLevel: Int = 1,
    val boundBank: String = "KBZ Pay",
    val boundAccount: String = "09666769539",
    val boundHolder: String = "Khant Hein soe",
    val isBound: Boolean = true
)

data class AdminPaymentInfo(
    val kbzName: String = "Lae Yee Win",
    val kbzPhone: String = "09894036935",
    val waveName: String = "Aung Myo Thu",
    val wavePhone: String = "09782194820"
)

data class WithdrawItem(
    val id: String,
    val bankType: String = "ဘဏ်ကတ်",
    val transId: String,
    val amount: Long,
    val date: String,
    val status: String = "အောင်မြင်မှု"
)

data class GameCard(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val jackpot1: Long = 0,
    val jackpot2: Long = 0,
    val imageRes: Int,
    val isFishGame: Boolean = false
)

data class SettingsState(
    val musicOn: Boolean = true,
    val soundOn: Boolean = true,
    val fxOn: Boolean = true,
    val announcementsOn: Boolean = true
)

data class ChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val time: String
)

enum class AppScreen {
    SPLASH,
    LOGIN,
    LOBBY
}

enum class LobbyDialogType {
    NONE,
    PROFILE,
    DEPOSIT,
    DEPOSIT_TRANSFER,
    INSTANT_ALERT,
    WITHDRAW,
    BIND_BANK,
    BIND_BANK_CARD,
    TRANSACTION_HISTORY,
    SETTINGS,
    VIP_BENEFITS,
    CUSTOMER_SERVICE,
    BANK_VAULT,
    ACTIVITY_CENTER,
    GAME_DEMO,
    EXIT_CONFIRM,
    ADMIN_PAYMENT_CONFIG
}
