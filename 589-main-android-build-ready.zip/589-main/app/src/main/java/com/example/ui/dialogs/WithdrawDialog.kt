package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.components.GoldPillButton
import com.example.ui.components.PurplePillButton
import com.example.ui.components.TempleRoofDialog
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoGreenDark
import com.example.ui.theme.CasinoGreenLight
import com.example.ui.theme.CasinoGreenPrimary
import com.example.ui.theme.CasinoRedBright
import com.example.ui.theme.CasinoRedDark
import com.example.ui.theme.CasinoRedPrimary

@Composable
fun WithdrawDialog(
    userProfile: UserProfile,
    withdrawAmount: Long,
    onWithdrawAmountChange: (Long) -> Unit,
    onMaxAmount: () -> Unit,
    onOpenRecords: () -> Unit,
    onBindBankCard: () -> Unit,
    onConfirmWithdraw: () -> Unit,
    onClose: () -> Unit
) {
    TempleRoofDialog(
        title = "ထုတ်ယူခြင်း",
        onClose = onClose,
        bottomActionText = "လုံလွယ်",
        onBottomAction = onConfirmWithdraw,
        modifier = Modifier.testTag("withdraw_dialog_root")
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Left Tab: "ဘဏ်ကတ်" (Bank Card)
            Column(
                modifier = Modifier
                    .width(130.dp)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.Top
            ) {
                GoldPillButton(
                    text = "ဘဏ်ကတ်",
                    onClick = { /* already active */ },
                    modifier = Modifier.fillMaxWidth(),
                    height = 38.dp,
                    fontSize = 14
                )
            }

            // Right Pane: Balance, Account, Slider and Amount Input
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Row 1: Balance + Records Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "ငွေ",
                        color = CasinoGoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(42.dp)
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(28.dp)
                            .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                            .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userProfile.coinBalance.toString(),
                            color = CasinoGoldLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    PurplePillButton(
                        text = "ငွေထုတ်မှတ်တမ်း",
                        onClick = onOpenRecords
                    )
                }

                // Row 2: Bank Number + Bind Card Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "ဘဏ်",
                        color = CasinoGoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(42.dp)
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(28.dp)
                            .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                            .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userProfile.boundAccount,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    PurplePillButton(
                        text = "ဘဏ်ကတ်ချည်နှောင်ခြင်း",
                        onClick = onBindBankCard
                    )
                }

                // Notice text: "10000 ကျပ်မှစ၍ငွေထုတ်ယူနိုင်ပြီး အနည်းဆုံးလက်ကျန်ငွေ 1000 ကျပ် ထားရှိရမည်။"
                Text(
                    text = "10000 ကျပ်မှစ၍ငွေထုတ်ယူနိုင်ပြီး အနည်းဆုံးလက်ကျန်ငွေ 1000 ကျပ် ထားရှိရမည်။",
                    color = Color(0xFFFF5252),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                // Subtitle: "ငွေထုတ်ပမာဏ" (Withdraw Amount)
                Text(
                    text = "ငွေထုတ်ပမာဏ",
                    color = CasinoGoldLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                // Amount row: Money bag icon + Amount Display + 'X' clear + "အကြီးဆုံး" (Max)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Blue coin pouch icon
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1565C0)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("💰", fontSize = 14.sp)
                    }

                    // Value box
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(28.dp)
                            .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                            .border(1.dp, CasinoGoldDark, RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = withdrawAmount.toString(),
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Red 'X' Button to clear amount
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(
                                brush = Brush.verticalGradient(
                                    listOf(CasinoRedBright, CasinoRedDark)
                                ),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(1.dp, CasinoGoldPrimary, RoundedCornerShape(4.dp))
                            .clickable { onWithdrawAmountChange(0L) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Purple "အကြီးဆုံး" (Max) button
                    PurplePillButton(
                        text = "အကြီးဆုံး",
                        onClick = onMaxAmount
                    )
                }

                // Slider with custom green progress and gold coin knob
                val maxAvailable = maxOf(userProfile.coinBalance.toFloat(), 1f)
                val currentSliderValue = (withdrawAmount.toFloat() / maxAvailable).coerceIn(0f, 1f)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Slider(
                        value = currentSliderValue,
                        onValueChange = { frac ->
                            val amt = (frac * userProfile.coinBalance).toLong()
                            onWithdrawAmountChange(amt)
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = CasinoGoldPrimary,
                            activeTrackColor = CasinoGreenPrimary,
                            inactiveTrackColor = Color(0xFF3E0A0E)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
