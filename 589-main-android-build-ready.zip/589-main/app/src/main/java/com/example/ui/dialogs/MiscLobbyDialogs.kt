package com.example.ui.dialogs

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AdminPaymentInfo
import com.example.data.model.GameCard
import com.example.data.model.UserProfile
import com.example.ui.components.GoldPillButton
import com.example.ui.components.GreenPillButton
import com.example.ui.components.RedPillButton
import com.example.ui.components.TempleRoofDialog
import com.example.ui.theme.CasinoGoldDark
import com.example.ui.theme.CasinoGoldLight
import com.example.ui.theme.CasinoGoldOrange
import com.example.ui.theme.CasinoGoldPrimary
import com.example.ui.theme.CasinoGreenDark
import com.example.ui.theme.CasinoGreenLight
import com.example.ui.theme.CasinoGreenPrimary
import com.example.ui.theme.CasinoRedDark
import com.example.ui.theme.CasinoRedPrimary
import kotlinx.coroutines.launch

/**
 * VIP Privileges Dialog ("VIP အကျိုးခံစားခွင့်")
 */
@Composable
fun VipDialog(
    userProfile: UserProfile,
    onClaimDailyBonus: () -> Unit,
    onClose: () -> Unit
) {
    TempleRoofDialog(
        title = "VIP အကျိုးခံစားခွင့်",
        onClose = onClose,
        modifier = Modifier.testTag("vip_dialog_root")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // VIP Level Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .background(Color(0xFF330005), RoundedCornerShape(6.dp))
                    .border(1.dp, CasinoGoldDark, RoundedCornerShape(6.dp))
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                brush = Brush.radialGradient(
                                    listOf(CasinoGoldLight, CasinoGoldPrimary, CasinoGoldDark)
                                ),
                                shape = CircleShape
                            )
                            .border(1.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "VIP ${userProfile.vipLevel}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF381400)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "လက်ရှိအဆင့်: VIP ${userProfile.vipLevel}",
                            color = CasinoGoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "နောက်တစ်ဆင့်: VIP 2 သို့ ရောက်ရန် 500 EXP လိုအပ်ပါသည်",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 10.sp
                        )
                    }
                }

                GreenPillButton(
                    text = "နေ့စဉ်ဆုလာဘ်ထုတ်ယူပါ",
                    onClick = onClaimDailyBonus,
                    height = 28.dp,
                    fontSize = 10
                )
            }

            // Benefits Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Benefit 1
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(75.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(6.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎁", fontSize = 18.sp)
                        Text("အဆင့်တက်ဆု", color = CasinoGoldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("5,000 Coins", color = Color.White, fontSize = 10.sp)
                    }
                }
                // Benefit 2
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(75.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(6.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⚡", fontSize = 18.sp)
                        Text("အပတ်စဉ် ငွေပြန်အမ်း", color = CasinoGoldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("0.5% Cashback", color = Color.White, fontSize = 10.sp)
                    }
                }
                // Benefit 3
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(75.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(6.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("👑", fontSize = 18.sp)
                        Text("သီးသန့် CS မန်နေဂျာ", color = CasinoGoldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("၂၄ နာရီ ကူညီပေးခြင်း", color = Color.White, fontSize = 10.sp)
                    }
                }
            }

            GoldPillButton(
                text = "ပိတ်ပါ",
                onClick = onClose,
                height = 32.dp,
                fontSize = 13
            )
        }
    }
}

/**
 * Bank Vault Dialog ("ဘဏ်သေတ္တာ" / Safe)
 */
@Composable
fun BankVaultDialog(
    userProfile: UserProfile,
    onDepositToVault: (Long) -> Unit,
    onWithdrawFromVault: (Long) -> Unit,
    onClose: () -> Unit
) {
    var vaultAmount by remember { mutableStateOf("1") }

    TempleRoofDialog(
        title = "ဘဏ်သေတ္တာ",
        onClose = onClose,
        modifier = Modifier.testTag("bank_vault_dialog_root")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Wallet Balance
                Box(
                    modifier = Modifier
                        .width(160.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(6.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🪙 ပိုက်ဆံအိတ် လက်ကျန်", color = CasinoGoldLight, fontSize = 11.sp)
                        Text("${userProfile.coinBalance}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Vault Balance (stored demo sycee)
                Box(
                    modifier = Modifier
                        .width(160.dp)
                        .background(Color(0xFF260103), RoundedCornerShape(6.dp))
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🧈 သေတ္တာထဲရှိ လက်ကျန်", color = CasinoGoldLight, fontSize = 11.sp)
                        Text("${userProfile.syceeBalance}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(0.7f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ပမာဏ: ", color = CasinoGoldLight, fontSize = 13.sp)
                OutlinedTextField(
                    value = vaultAmount,
                    onValueChange = { vaultAmount = it },
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF260103),
                        unfocusedContainerColor = Color(0xFF260103),
                        focusedIndicatorColor = CasinoGoldPrimary,
                        unfocusedIndicatorColor = CasinoGoldDark
                    ),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                GreenPillButton(
                    text = "သေတ္တာထဲသို့ ထည့်မည်",
                    onClick = {
                        val amt = vaultAmount.toLongOrNull() ?: 0L
                        onDepositToVault(amt)
                    },
                    height = 32.dp,
                    fontSize = 12
                )

                GoldPillButton(
                    text = "သေတ္တာထဲမှ ထုတ်ယူမည်",
                    onClick = {
                        val amt = vaultAmount.toLongOrNull() ?: 0L
                        onWithdrawFromVault(amt)
                    },
                    height = 32.dp,
                    fontSize = 12
                )
            }
        }
    }
}

/**
 * Activity Center Dialog ("လှုပ်ရှားမှုစင်တာ")
 */
@Composable
fun ActivityCenterDialog(
    onClaimSpin: () -> Unit,
    onClose: () -> Unit
) {
    TempleRoofDialog(
        title = "လှုပ်ရှားမှုစင်တာ",
        onClose = onClose,
        modifier = Modifier.testTag("activity_center_dialog_root")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Activity 1: Lion Dance Spin
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(95.dp)
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(Color(0xFF5A1418), Color(0xFF2E0508))
                            ),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .border(1.dp, CasinoGoldPrimary, RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🦁 ခြင်္သေ့အက ကံစမ်းမဲ", color = CasinoGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("အခမဲ့ လှည့်ခွင့် (၁) ကြိမ်", color = Color.White, fontSize = 10.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        GreenPillButton(text = "ကံစမ်းမည်", onClick = onClaimSpin, height = 24.dp, fontSize = 10)
                    }
                }

                // Activity 2: Weekend Bonus
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(95.dp)
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(Color(0xFF5A1418), Color(0xFF2E0508))
                            ),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .border(1.dp, CasinoGoldDark, RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎉 စနေ/တနင်္ဂနွေ အပိုဆု", color = CasinoGoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("ငွေသွင်းတိုင်း 10% အပိုလက်ဆောင်", color = Color.White, fontSize = 10.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        GoldPillButton(text = "ပါဝင်မည်", onClick = onClaimSpin, height = 24.dp, fontSize = 10)
                    }
                }
            }

            GoldPillButton(text = "ပိတ်ပါ", onClick = onClose, height = 30.dp, fontSize = 12)
        }
    }
}

/**
 * Game Coming Soon / Demo Spin Dialog
 */
@Composable
fun GameDemoDialog(
    game: GameCard?,
    onClose: () -> Unit
) {
    if (game == null) return
    val coroutineScope = rememberCoroutineScope()
    var isSpinning by remember { mutableStateOf(false) }
    var winResult by remember { mutableStateOf<String?>(null) }

    TempleRoofDialog(
        title = game.title,
        onClose = onClose,
        modifier = Modifier.testTag("game_demo_dialog_root")
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Game Poster
            Box(
                modifier = Modifier
                    .width(130.dp)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(8.dp))
                    .border(2.dp, CasinoGoldPrimary, RoundedCornerShape(8.dp))
            ) {
                Image(
                    painter = painterResource(id = game.imageRes),
                    contentDescription = game.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Info & Demo Spin
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = game.title,
                        color = CasinoGoldLight,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = game.subtitle,
                        color = CasinoGoldDark,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    if (game.jackpot1 > 0) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF260103), RoundedCornerShape(4.dp))
                                .border(1.dp, CasinoGoldPrimary, RoundedCornerShape(4.dp))
                                .padding(horizontal = 12.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "JACKPOT: ${game.jackpot1}",
                                color = Color(0xFFFFD54F),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }

                // Demo Notice
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF38080C), RoundedCornerShape(6.dp))
                        .border(1.dp, Color(0xFF6B1A22), RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "ဂိမ်း Demo — မကြာမီလာမည် (Coming Soon)",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (winResult != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = winResult!!,
                                color = CasinoGreenLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }

                // Demo Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    GreenPillButton(
                        text = if (isSpinning) "လည်ပတ်နေပါသည်..." else "စမ်းသပ်လည်ပတ်မည် (Demo)",
                        onClick = {
                            if (!isSpinning) {
                                isSpinning = true
                                winResult = null
                                coroutineScope.launch {
                                    kotlinx.coroutines.delay(1200)
                                    isSpinning = false
                                    winResult = "🎉 ဂုဏ်ယူပါသည်! +${(1000..50000).random()} Coins အနိုင်ရရှိသည်!"
                                }
                            }
                        },
                        height = 32.dp,
                        fontSize = 11
                    )

                    RedPillButton(
                        text = "ပိတ်ပါ",
                        onClick = onClose,
                        height = 32.dp,
                        fontSize = 11
                    )
                }
            }
        }
    }
}

/**
 * Admin Payment Settings Dialog (Prompt requirement 7)
 */
@Composable
fun AdminPaymentConfigDialog(
    currentInfo: AdminPaymentInfo,
    onSave: (String, String, String, String) -> Unit,
    onClose: () -> Unit
) {
    var kbzName by remember { mutableStateOf(currentInfo.kbzName) }
    var kbzPhone by remember { mutableStateOf(currentInfo.kbzPhone) }
    var waveName by remember { mutableStateOf(currentInfo.waveName) }
    var wavePhone by remember { mutableStateOf(currentInfo.wavePhone) }

    TempleRoofDialog(
        title = "ငွေပေးချေမှု Demo ပြင်ဆင်ရန်",
        onClose = onClose,
        bottomActionText = "သိမ်းဆည်းပါ",
        onBottomAction = {
            onSave(kbzName, kbzPhone, waveName, wavePhone)
            onClose()
        },
        modifier = Modifier.testTag("admin_payment_dialog_root")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "KBZ Pay & WavePay Demo အကောင့်အချက်အလက်များကို ပြင်ဆင်နိုင်ပါသည် (ငွေသွင်း UI တွင် ပြောင်းလဲပါမည်)",
                color = CasinoGoldLight,
                fontSize = 11.sp
            )

            // KBZ Name & Phone
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = kbzName,
                    onValueChange = { kbzName = it },
                    label = { Text("KBZ အမည်", color = CasinoGoldDark, fontSize = 10.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF260103),
                        unfocusedContainerColor = Color(0xFF260103),
                        focusedIndicatorColor = CasinoGoldPrimary,
                        unfocusedIndicatorColor = CasinoGoldDark
                    ),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = kbzPhone,
                    onValueChange = { kbzPhone = it },
                    label = { Text("KBZ ဖုန်း", color = CasinoGoldDark, fontSize = 10.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF260103),
                        unfocusedContainerColor = Color(0xFF260103),
                        focusedIndicatorColor = CasinoGoldPrimary,
                        unfocusedIndicatorColor = CasinoGoldDark
                    ),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            // Wave Name & Phone
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = waveName,
                    onValueChange = { waveName = it },
                    label = { Text("Wave အမည်", color = CasinoGoldDark, fontSize = 10.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF260103),
                        unfocusedContainerColor = Color(0xFF260103),
                        focusedIndicatorColor = CasinoGoldPrimary,
                        unfocusedIndicatorColor = CasinoGoldDark
                    ),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = wavePhone,
                    onValueChange = { wavePhone = it },
                    label = { Text("Wave ဖုန်း", color = CasinoGoldDark, fontSize = 10.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF260103),
                        unfocusedContainerColor = Color(0xFF260103),
                        focusedIndicatorColor = CasinoGoldPrimary,
                        unfocusedIndicatorColor = CasinoGoldDark
                    ),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/**
 * Exit Confirmation Dialog
 */
@Composable
fun ExitConfirmDialog(
    onConfirmExit: () -> Unit,
    onCancel: () -> Unit
) {
    TempleRoofDialog(
        title = "ဂိမ်းမှ ထွက်ခွာခြင်း",
        onClose = onCancel,
        modifier = Modifier.testTag("exit_confirm_dialog_root")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "ဂိမ်းမှ ထွက်ခွာလိုပါသလား?",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                RedPillButton(
                    text = "ထွက်မည်",
                    onClick = onConfirmExit,
                    height = 34.dp,
                    fontSize = 13
                )

                GreenPillButton(
                    text = "ပယ်ဖျက်ပါ",
                    onClick = onCancel,
                    height = 34.dp,
                    fontSize = 13
                )
            }
        }
    }
}
