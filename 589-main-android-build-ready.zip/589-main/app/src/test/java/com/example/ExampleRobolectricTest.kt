package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AdminPaymentInfo
import com.example.data.model.AppScreen
import com.example.data.model.LobbyDialogType
import com.example.data.model.UserProfile
import com.example.data.repository.LobbyRepository
import com.example.ui.viewmodel.LobbyViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppName() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("589 Slot", appName)
    }

    @Test
    fun testLobbyRepositoryPersistence() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = LobbyRepository(context)

        // Initial default state
        val initialProfile = repo.userProfile.value
        assertEquals("79018626", initialProfile.userId)
        assertEquals("79018626", initialProfile.nickname)

        // Update profile
        val updated = initialProfile.copy(nickname = "LuckyWinner99", coinBalance = 9999L)
        repo.saveUserProfile(updated)

        assertEquals("LuckyWinner99", repo.userProfile.value.nickname)
        assertEquals(9999L, repo.userProfile.value.coinBalance)

        // Update Admin payment
        val customPayment = AdminPaymentInfo(
            kbzName = "Demo KBZ User",
            kbzPhone = "09123456789",
            waveName = "Demo Wave User",
            wavePhone = "09987654321"
        )
        repo.saveAdminPayment(customPayment)
        assertEquals("Demo KBZ User", repo.adminPayment.value.kbzName)
        assertEquals("09123456789", repo.adminPayment.value.kbzPhone)
    }

    @Test
    fun testLobbyViewModelNavigationAndDialogs() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = LobbyViewModel(app)

        // Quick Guest Login
        viewModel.loginQuickGuest()
        assertEquals(AppScreen.LOBBY, viewModel.currentScreen.value)

        // Open and close dialogs
        viewModel.openDialog(LobbyDialogType.PROFILE)
        assertEquals(LobbyDialogType.PROFILE, viewModel.activeDialog.value)

        viewModel.closeDialog()
        assertEquals(LobbyDialogType.NONE, viewModel.activeDialog.value)

        // Deposit selection
        viewModel.setDepositMethod("WAVEPAY")
        assertEquals("WAVEPAY", viewModel.selectedDepositMethod.value)

        viewModel.setDepositAmount(50000L)
        assertEquals(50000L, viewModel.depositAmount.value)

        // Game catalog
        assertTrue(viewModel.gameCards.isNotEmpty())
        val firstGame = viewModel.gameCards.first()
        viewModel.onGameCardClicked(firstGame)
        assertEquals(LobbyDialogType.GAME_DEMO, viewModel.activeDialog.value)
        assertEquals(firstGame, viewModel.selectedGame.value)
    }
}
